#Codio Coding Activity 4.1: Database Selection and Design - Solution File

#Question 1 - Select the Trips Table: 
#Rearrange the code blocks below to view all the records in the table trips.

#Solution:
USE EPDriver;
SELECT * FROM trips;


#Question 2 - Select a Column
#Using the EPDriver database, type the commands in the Terminal on the left to select the column trip_datetime_end.

#Solution:
USE EPDriver;
SELECT trip_datetime_end FROM trips;

#Question 3 - Selecting NULL Values
#Rearrange the code blocks below to view all the records where trip_total_fare is equal to NULL.

#Solution:
USE EPDriver;
SELECT * FROM trips WHERE trip_total_fare IS NULL;

#Question 4 - Create the Listings Table
What is the command to define the table Listings according to the instructions above?

#Solution:
USE EPDriver;
CREATE TABLE `Listings` (`Square Footage` int NOT NULL, `Neighborhood` varchar(10) NOT NULL, `Property Taxes` float NOT NULL);

#Question 5 - Show the Tables in Your Database
#In the terminal command window on the left, type the correct command to show all tables in the EPDriver database.

#Solution:
USE EPDriver;
SHOW TABLES;

#Question 6 - Drop the Drivers Table
#In the terminal command window on the left, type the correct commands to drop the drivers table in the EPDriver database.

#Solution:
USE EPDriver;
DROP TABLE drivers;
SHOW TABLES;
