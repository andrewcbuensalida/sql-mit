Use Times;
SELECT TIMEDIFF('07:24:09', '08:10:45') as TimeDiff;