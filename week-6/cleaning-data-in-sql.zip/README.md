# Hello Codio in SQL
This project shows you a sample lesson page in Codio and then explains how it was built. It then demonstrates Codio's auto-graded assessment capabilities.

Feel free to edit and try things out – if you need a new copy of this project use one of the links below then click **Use Pack** and click **Create** to add it to your projects.

For Codio.com users, go to this [Starter Pack](https://codio.com/home/starter-packs/20be909f-a90c-4b79-83dc-e43d656e30dc).
For Codio.co.uk users, go to this [Starter Pack](https://codio.co.uk/home/starter-packs/1a951f37-fcdf-48f5-819d-007e9080e198).


## Start the Guide to see the project
If you are seeing this, you are currently in edit mode. To start Guides from this page, go to the tool bar at the top:
![.guides/img/playGuide](.guides/img/playGuide.png)

To view projects the way students do, press "Yes" when prompted to Start Guides.
