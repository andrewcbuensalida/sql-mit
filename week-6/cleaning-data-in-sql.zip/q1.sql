USE Schools;
select avg(weight_in_lbs) as average_weight_in_lbs from Entries;