-- Codio Coding Assignment 5.1: Module 5 Final Assignment: Handling a Database

-- Question 1 - Display the Tables
-- What are the commands to show the tables in a dataset?

-- Solution:
USE education;
SHOW TABLES;


-- Question 2 - Visualize The Colleges Table
-- In the file window, type the commands to visualize the entries in the table Colleges.

-- Solution:
USE education;
SELECT * FROM Colleges;


-- Question 3 - Retrieve Records in The Students Table
-- In the file window, type the correct commands to visualize all the entries in the Students table.

-- Solution:
USE education;
SELECT * FROM Students

-- Question 4 - Retrieve Records in The Students Table
-- In the file window, type the correct commands to visualize all the entries in the Students table.

-- Solution:
USE education;
SELECT * FROM Students WHERE Region= 'WA';

-- Question 5 - Retrieve Records in The Students Table
-- Rearrange the code blocks below to retrieve entries from the Students table as directed above.

-- Solution:
USE education;
SELECT City, Region, Country FROM Students WHERE Region = 'FL';


-- Question 6 - Selecting Columns
-- In the file command window on the left, type the correct command to retrieve records according to the instructions above.

-- Solution:
USE Education;
SELECT * FROM Students WHERE BirthDate <'1995-06-01';
-- 
-- Question 7 - Concatenate Columns
-- In the file window, type the commands to display the names of the cities, states, and country as described above.

-- Solution:
USE Education;
SELECT City, Region, Country, CONCAT(City, ', ', Region, ' ', Country) AS Location FROM Students;

-- Question 8 - Select Records With The IN Operator
-- In the file window, type the correct commands to retrieve the desired entries in the Students table using the IN operator.

-- Solution:
USE Education;
SELECT * FROM Students WHERE City IN ('Seattle', 'Miami', 'Chicago');

-- Question 9 - Combining Operators
-- In the file window, type the correct commands to retrieve the entries in the Colleges table as described above.

-- Solution:
USE Education;
SELECT * FROM Colleges WHERE City IN ('Cambridge') AND CollegeID > 5;

-- Question 10 - Combining Operators
-- In the Terminal window, type the correct commands to retrieve the entries in the Students table as described above.

-- Solution:
USE Education;
SELECT * FROM Students WHERE Region IN ('WA', 'TN') AND City NOT IN ('New York') OR CollegeID > 6 AND BirthDate BETWEEN '1993-01-01' AND '1995-05-01';
-- Question 11 - Select NOT NULL Phone Numbers
-- In the file window, type the correct commands to retrieve the entries in the Students table as described above.

-- Solution:
USE Education;
SELECT * FROM  Students WHERE Phone IS NOT NULL;

-- Question 12 - Select NULL FriendID
-- In the file window, type the correct commands to retrieve the entries in the Students table according to the instructions above.

-- Solution:
USE Education;
SELECT * FROM  Students WHERE FriendID IS NULL;


-- Question 13 - The LIKE Operator
-- In the file window, type the correct commands to retrieve the entries in the Colleges table as described above.

-- Solution:
USE Education;
SELECT * FROM Colleges WHERE Name LIKE 'N%';

-- Question 14 - Combining Operators II
-- In the file window, type the correct commands to retrieve the entries in the Students table as described above.

-- Solution:
USE Education;
SELECT * FROM Students  WHERE  Email LIKE '%apple%' OR Phone LIKE '(415%';

-- Question 15 - Inner Join
-- In the file window, type the correct commands to perform an inner join as described above. 

-- Solution:
USE Education;
SELECT  Students.LastName, Colleges.CollegeID, Colleges.City, Colleges.Region FROM Students INNER JOIN Colleges ON Students.CollegeID = Colleges.CollegeID;
-- Question 16 - Inner Join
-- In the file window, type the correct commands to perform a left  join as described above. 

-- Solution:
USE Education;
SELECT  Students.FirstName,  Students.LastName, Students.Email, Colleges.CollegeID, Colleges.City FROM Students LEFT  JOIN Colleges ON Students.CollegeID = Colleges.CollegeID;

-- Question 17 - Order Email Column 
-- In the file window, type the correct commands to sort the entries in the column Emails in the Students table according to the instructions above.

-- Solution:
USE Education;
SELECT * FROM Students ORDER BY Email DESC;

-- Question 18 - Aggregating Data I
-- In the file window, type the correct commands to produce the table above.

-- Solution:
USE Education;
SELECT count(*) 'Count', Name FROM Colleges GROUP BY Name;

-- Question 19 - Select Maximum
-- In the file window, type the correct commands to produce the table above.

-- Solution:
USE Education;
SELECT MAX(Students) FROM Colleges;
